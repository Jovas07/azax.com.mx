<?php
/**
Plugin Name: LC Theme Custom Post
Plugin URI: http://lion-coders.com/
Description: A plugin that adds portfolio post type.
Version: 1.0
Author: LionCoders
Author URI: http://lion-coders.com/
*/

if(!class_exists('lcThemeCustomPost')) {
	class lcThemeCustomPost {

		public function __construct(){
			add_action('plugins_loaded', array($this, 'lc_theme_custom_post_load'));
		}

		public function lc_theme_custom_post_load(){
			if ( !function_exists( 'lc_register_custom_post' ) ) {
				function lc_register_custom_post() {
					register_post_type( 'portfolio', array(
						'labels'			=>	array(
							'name'			=>	__( 'Portfolio', 'hello' ),
							'add_new'		=>	__( 'Add New Portfolio', 'hello' ),
							'add_new_item'	=>	__( 'Add New Portfolio', 'hello' ),
						),
						'public'			=>	true,
						'supports'			=>	array( 'title', 'thumbnail', 'editor' ),
						'menu_icon'			=>	'dashicons-portfolio'
					) );

					register_taxonomy( 'portfolio-category', 'portfolio', array(
						'labels'			=>	array(
							'name'			=>	__( 'categories', 'hello' ),
							'add_new'		=>	__( 'Add New Category', 'hello' ),
							'add_new_item'	=>	__( 'Add New Category', 'hello' ),
						),
						'public'			=>	true,
						'hierarchical'		=>	true,
					) );
				}
				add_action('init', 'lc_register_custom_post');
			}
		}

	}
}
$lc_theme_custom_post = new lcThemeCustomPost();