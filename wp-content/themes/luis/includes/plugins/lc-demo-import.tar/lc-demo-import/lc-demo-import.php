<?php
/**
Plugin Name: LC Demo Import
Plugin URI: http://lion-coders.com/
Description: A plugin that imports demo.
Version: 1.0
Author: LionCoders
Author URI: http://lion-coders.com/
*/
